# Bazaar Mobiles

A one-page web app for a mobile phone store: latest models, prices in PKR, specs, a colour scheme per phone, and a daily sales counter.

## Run it
Open `index.html` in any browser. No build step or install needed.

## Host it free on GitHub Pages
1. Push these files to a GitHub repository.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site appears at `https://<your-username>.github.io/<repo-name>/` after a minute or two.

## Edit the phones
Open `index.html` and find the `PHONES` list near the bottom. Change the names, prices (PKR), specs and colourways there. The prices and specs that come with it are sample values.

## Notes
- The daily sales count is saved in the browser (localStorage) on one device and resets each new day.
- The Google font loads online. If it can’t, the page uses the system font.
